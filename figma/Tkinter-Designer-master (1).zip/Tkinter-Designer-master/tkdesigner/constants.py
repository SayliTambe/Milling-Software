# Path to assets directory (i.e. images) relative to the output directory.
ASSETS_PATH = "./assets"
